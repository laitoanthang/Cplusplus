#include <iostream>
using namespace std;

int main()
{
	int a = 5;
	int b = 6;

	printf("- Value: a =%d, b=%d\n", a, b);
	printf("- Address: a=%d, b=%d\n", &a, &b);

	return 0;
}