C++
-----------------------------------------------------------------------------------
At Project 2, you will know how to allocate an dynamic array consist of n positive interger
To Run The Project, you will do Ctrl + F5
and do Follow the Console's Screen order...
At this project, the result will be known how many ellement which are devisible to 6 and the last one is 6 too.
The average of Prime numbers....
Count the prime which is not duplicate in the array

YOU CAN FOLLOW THE CONSOLE'S SCREEEN ORDER AS WELL.