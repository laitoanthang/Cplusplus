C++
-----------------------------------------------------------------------------------
At Project 5, you will know how about struct (fraction)
To Run The Project, you will do Ctrl + F5
and do Follow the Console's Screen order...
You'll know the result. It is very exciting!
