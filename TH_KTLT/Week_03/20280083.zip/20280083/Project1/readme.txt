C++
-----------------------------------------------------------------------------------
The C++ language and projects built on top of it are essential to the platform.
This is the place to start for developing and deploying C++.
Through this coding you will how to dynamically allocate an array as well as input an array, initialize a variable
The result will be the value and the position of the divisor by X in the array.
After move elements - divisor by X to the end of the array and guarantee the front as back order in the array.
And finally, arrange elements are not a divisor of X in ascending order 

YOU CAN FOLLOW THE CONSOLE'S SCREEEN ORDER AS WELL.
