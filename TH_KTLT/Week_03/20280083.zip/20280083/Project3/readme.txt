C++
-----------------------------------------------------------------------------------
At Project 3, you will know how to allocate an dynamic array consist of n positive interger
To Run The Project, you will do Ctrl + F5
and do Follow the Console's Screen order...
