C++
-----------------------------------------------------------------------------------
At Project 6, you will know how to struct Circle inclule coodinates (x;y) and the radius (r)
To Run The Project, you will do Ctrl + F5
and do Follow the Console's Screen order...
